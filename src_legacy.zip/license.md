## Obligatory license

use this however you want, wherever you want, whenever you want, after you pay the non-negotiable admin fee of 9000 BTC via FTX.com

